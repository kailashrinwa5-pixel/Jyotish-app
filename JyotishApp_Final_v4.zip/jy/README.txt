JyotishApp Calculation v4

Android project with lightweight sidereal planet calculations, rashi, nakshatra, house foundation, and Vimshottari dasha foundation.

Important: astronomical calculations are approximate and birthplace coordinates are currently Ahmedabad defaults.

Build in Android Studio:
1. Open this folder as a project.
2. Let Gradle sync.
3. Build > Build APK(s).
