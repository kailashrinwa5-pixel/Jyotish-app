package com.jyotish.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    EditText name, date, time, place;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    TextView title(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(50,40,35));
        t.setPadding(dp(4),dp(8),dp(4),dp(8));
        return t;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false);
        return b;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        home();
    }

    void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(255,250,244));

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20),dp(18),dp(20),dp(24));
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    void home() {
        base();
        TextView h = title("🔱 ज्योतिष ऐप", 28);
        h.setGravity(Gravity.CENTER);
        content.addView(h);

        content.addView(title("एक ऐप — अनेक ज्योतिष पद्धतियों का आधार", 16));

        Button create = button("नई जन्म कुंडली बनाएँ");
        content.addView(create);
        create.setOnClickListener(v -> birth());

        content.addView(title("इस version में",20));
        content.addView(title(
            "• जन्म विवरण\n• Kundli profile\n• लग्न/राशि/भाव के लिए calculation foundation\n" +
            "• नक्षत्र और दशा modules के लिए architecture\n• आगे Parashari, KP, Jaimini, Nadi और Lal Kitab",
            16));
    }

    EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setPadding(dp(12),dp(4),dp(12),dp(4));
        content.addView(e, new LinearLayout.LayoutParams(-1,dp(58)));
        return e;
    }

    void birth() {
        base();
        content.addView(title("जन्म विवरण", 26));
        name=field("नाम");
        date=field("जन्म तारीख  (DD/MM/YYYY)");
        time=field("जन्म समय  (HH:MM)");
        place=field("जन्म स्थान");

        Button make=button("कुंडली तैयार करें");
        content.addView(make);
        make.setOnClickListener(v -> result());
        Button back=button("← वापस");
        content.addView(back);
        back.setOnClickListener(v -> home());
    }

    void result() {
        String n=name.getText().toString().trim(); String d=date.getText().toString().trim(); String tm=time.getText().toString().trim(); String p=place.getText().toString().trim();
        if(n.isEmpty() || d.isEmpty() || tm.isEmpty() || p.isEmpty()) { Toast.makeText(this,"कृपया सभी जन्म विवरण भरें",Toast.LENGTH_LONG).show(); return; }
        try {
            String[] ds=d.split("/"); String[] ts=tm.split(":"); int Y=Integer.parseInt(ds[2]), M=Integer.parseInt(ds[1]), D=Integer.parseInt(ds[0]); int hh=Integer.parseInt(ts[0]), mm=Integer.parseInt(ts[1]);
            double jd=AstroCalculator.julian(Y,M,D,hh,mm); List<AstroCalculator.Planet> ps=AstroCalculator.planets(jd);
            base(); content.addView(title("🪐 कुंडली प्रोफ़ाइल",26)); content.addView(title("नाम: "+n+"\nजन्म: "+d+"  "+tm+"\nस्थान: "+p,17));
            content.addView(title("ग्रह स्थिति (साइडीरियल)",21));
            for(AstroCalculator.Planet x:ps) content.addView(title(x.name+"  —  "+String.format(Locale.US,"%.2f°",x.lon)+"  "+AstroCalculator.rashi(x.lon)+"  |  "+AstroCalculator.nakshatra(x.lon),16));
            content.addView(title("12 भाव / राशि आधार",21));
            String[] hs=AstroCalculator.houses(jd,23.02,72.57); for(int i=0;i<12;i++) content.addView(title((i+1)+" भाव  —  "+hs[i],16));
            content.addView(title("नक्षत्र",21)); if(!ps.isEmpty()) content.addView(title("चंद्र नक्षत्र: "+AstroCalculator.nakshatra(ps.get(ps.size()-1).lon),16));
            content.addView(title("विम्शोत्तरी दशा",21)); String[] dl={"केतु","शुक्र","सूर्य","चंद्र","मंगल","राहु","गुरु","शनि","बुध"}; int idx=AstroCalculator.vimshottariLord(ps.get(ps.size()-1).lon); content.addView(title("जन्म नक्षत्र के स्वामी: "+dl[idx]+"\nदशा क्रम: "+dl[idx]+" → "+dl[(idx+1)%9]+" → "+dl[(idx+2)%9]+" → ...",16));
            content.addView(title("नोट: ग्रह गणना lightweight astronomical approximation है; स्थान के latitude/longitude को अभी Ahmedabad default रखा गया है।",14));
            Button back=button("← नई कुंडली"); content.addView(back); back.setOnClickListener(v -> birth());
        } catch(Exception e) { Toast.makeText(this,"तारीख DD/MM/YYYY और समय HH:MM सही भरें",Toast.LENGTH_LONG).show(); }
    }
}
