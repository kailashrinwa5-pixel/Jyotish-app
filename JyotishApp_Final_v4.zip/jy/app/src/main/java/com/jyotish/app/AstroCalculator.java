package com.jyotish.app;

import java.util.*;

/** Lightweight Vedic astrology engine. Planet positions use low-precision orbital elements,
 * sufficient for a mobile preview; sidereal conversion uses a Lahiri-style ayanamsha approximation. */
public class AstroCalculator {
  public static class Planet { public String name; public double lon; public Planet(String n,double l){name=n;lon=norm(l);} }
  static double norm(double x){x%=360; if(x<0)x+=360; return x;}
  static double sind(double x){return Math.sin(Math.toRadians(x));}
  static double cosd(double x){return Math.cos(Math.toRadians(x));}
  static double tand(double x){return Math.tan(Math.toRadians(x));}
  static double atan2d(double y,double x){return norm(Math.toDegrees(Math.atan2(y,x)));}
  static double jd(int Y,int M,int D,double hour){ if(M<=2){Y--;M+=12;} int A=Y/100; int B=2-A+A/4; return Math.floor(365.25*(Y+4716))+Math.floor(30.6001*(M+1))+D+B-1524.5+hour/24.0; }
  public static double julian(int y,int m,int d,int hh,int min){return jd(y,m,d,hh+min/60.0);}
  public static double ayanamsha(double jd){ double T=(jd-2451545.0)/36525.0; return 23.8531 + 1.39656*T + 0.000308*T*T; }
  static double kepler(double M,double e){double E=Math.toRadians(M); for(int i=0;i<10;i++) E-=(E-e*Math.sin(E)-Math.toRadians(M))/(1-e*Math.cos(E)); return Math.toDegrees(E);}
  // Elements from Paul Schlyter's compact solar-system approximation.
  static double[] elem(String p,double d){
    double N,i,w,a,e,M;
    if(p.equals("Mercury")){N=48.3313+3.24587E-5*d;i=7.0047+5E-8*d;w=29.1241+1.01444E-5*d;a=.387098;e=.205635+5.59E-10*d;M=168.6562+4.0923344368*d;}
    else if(p.equals("Venus")){N=76.6799+2.46590E-5*d;i=3.3946+2.75E-8*d;w=54.8910+1.38374E-5*d;a=.72333;e=.006773-1.302E-9*d;M=48.0052+1.6021302244*d;}
    else if(p.equals("Mars")){N=49.5574+2.11081E-5*d;i=1.8497-1.78E-8*d;w=286.5016+2.92961E-5*d;a=1.523688;e=.093405+2.516E-9*d;M=18.6021+.5240207766*d;}
    else if(p.equals("Jupiter")){N=100.4542+2.76854E-5*d;i=1.3030-1.557E-7*d;w=273.8777+1.64505E-5*d;a=5.20256;e=.048498+4.469E-9*d;M=19.8950+.0830853001*d;}
    else {N=113.6634+2.38980E-5*d;i=2.4886-1.081E-7*d;w=339.3939+2.97661E-5*d;a=9.55475;e=.055546-9.499E-9*d;M=316.9670+.0334442282*d;}
    return new double[]{N,i,w,a,e,M};
  }
  static double[] xyz(String p,double d){double[] q=elem(p,d); double N=q[0],i=q[1],w=q[2],a=q[3],e=q[4],M=norm(q[5]); double E=kepler(M,e), xv=a*(Math.cos(Math.toRadians(E))-e), yv=a*Math.sqrt(1-e*e)*Math.sin(Math.toRadians(E)); double v=atan2d(yv,xv),r=Math.hypot(xv,yv); double xh=r*(cosd(N)*cosd(v+w)-sind(N)*sind(v+w)*cosd(i)); double yh=r*(sind(N)*cosd(v+w)+cosd(N)*sind(v+w)*cosd(i)); double zh=r*sind(v+w)*sind(i); return new double[]{xh,yh,zh}; }
  static double[] sunEcl(double d){double w=282.9404+4.70935E-5*d,e=.016709-1.151E-9*d,M=356.0470+.9856002585*d,E=kepler(M,e); double xv=Math.cos(Math.toRadians(E))-e,yv=Math.sqrt(1-e*e)*Math.sin(Math.toRadians(E)); return new double[]{atan2d(yv,xv),Math.hypot(xv,yv)};}
  public static List<Planet> planets(double jd){double d=jd-2451543.5; double[] se=sunEcl(d); double sun=norm(se[0]+se[1]*0); double[] out=new double[9]; out[0]=sun; double[] earth=xyzEarth(d); double[] names={0};
    List<Planet> r=new ArrayList<>(); r.add(new Planet("सूर्य",sun));
    String[] ps={"Mercury","Venus","Mars","Jupiter","Saturn"}; String[] hi={"बुध","शुक्र","मंगल","गुरु","शनि"};
    for(int k=0;k<ps.length;k++){double[] v=xyz(ps[k],d); double x=v[0]-earth[0],y=v[1]-earth[1],z=v[2]-earth[2]; r.add(new Planet(hi[k],norm(atan2d(y,x)-ayanamsha(jd))));}
    // Sun above was tropical; convert it here. Moon is computed separately.
    r.set(0,new Planet("सूर्य",sun-ayanamsha(jd)));
    double ay=ayanamsha(jd); r.add(new Planet("चंद्र",moonLon(jd)-ay));
    double node=norm(125.1228-0.0529538083*d)-ay; r.add(new Planet("राहु",node)); r.add(new Planet("केतु",node+180));
    return r;
  }
  static double[] xyzEarth(double d){double[] se=sunEcl(d); double lon=norm(se[0]+180); return new double[]{se[1]*cosd(lon),se[1]*sind(lon),0};}
  static double moonLon(double jd){double d=jd-2451543.5; double N=125.1228-0.0529538083*d,i=5.1454,w=318.0634+0.1643573223*d,a=60.2666,e=.054900,M=115.3654+.0027377785*d; double E=kepler(M,e), xv=a*(Math.cos(Math.toRadians(E))-e),yv=a*Math.sqrt(1-e*e)*Math.sin(Math.toRadians(E)); double v=atan2d(yv,xv),r=Math.hypot(xv,yv); double xh=r*(cosd(N)*cosd(v+w)-sind(N)*sind(v+w)*cosd(i)),yh=r*(sind(N)*cosd(v+w)+cosd(N)*sind(v+w)*cosd(i)); double lon=atan2d(yh,xh); // perturbation terms omitted; add principal solar elongation correction
    double sun=sunEcl(d)[0]; double D=norm(lon-sun); lon += 6.289*sind(M)+1.274*sind(2*(lon-sun)-M)+0.658*sind(2*(lon-sun))-0.214*sind(2*M); return norm(lon);
  }
  public static String rashi(double lon){String[] z={"मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुला","वृश्चिक","धनु","मकर","कुंभ","मीन"};return z[(int)(norm(lon)/30)];}
  public static String nakshatra(double lon){String[] n={"अश्विनी","भरणी","कृत्तिका","रोहिणी","मृगशिरा","आर्द्रा","पुनर्वसु","पुष्य","आश्लेषा","मघा","पूर्वाफाल्गुनी","उत्तराफाल्गुनी","हस्त","चित्रा","स्वाती","विशाखा","अनुराधा","ज्येष्ठा","मूल","पूर्वाषाढ़ा","उत्तराषाढ़ा","श्रवण","धनिष्ठा","शतभिषा","पूर्वाभाद्रपद","उत्तराभाद्रपद","रेवती"}; return n[(int)(norm(lon)/(360.0/27))];}
  public static String[] houses(double jd,double lat,double lon){double T=(jd-2451545)/36525.0; double gst=norm(280.46061837+360.98564736629*(jd-2451545)+0.000387933*T*T); double lst=norm(gst+lon); double ra=atan2d(sind(lst),cosd(lst)); double asc=norm(ra-Math.toDegrees(Math.atan2(cosd(lst),Math.tan(Math.toRadians(lat))))); String[] h=new String[12]; for(int i=0;i<12;i++) h[i]=rashi(asc+i*30); return h;}
  public static int vimshottariLord(double lon){String[] l={"केतु","शुक्र","सूर्य","चंद्र","मंगल","राहु","गुरु","शनि","बुध"}; return (int)(norm(lon)/(360.0/27))%9;}
}
